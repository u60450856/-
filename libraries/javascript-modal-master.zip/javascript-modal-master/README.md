# Simple JavaScript Modal Plugin

## Install

```html
<link rel="stylesheet" href="modal.css">
...
<script src="modal.js"></script>
```

## Use
```javascript
var modal = new Modal('selector');
modal.show();
modal.hide();
```

##Licence
MIT